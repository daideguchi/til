//
//  SEManager.swift
//  FishPiano
//
//  Created by Yukinaga2 on 2017/11/28.
//  Copyright © 2017年 Yukinaga Azuma. All rights reserved.
//

import UIKit
import AVFoundation

class SEManager: NSObject, AVAudioPlayerDelegate {
    
    static let shared = SEManager()
    var sePool = [AVAudioPlayer]()
    
    func play(fileName: String){
        let url = URL(fileURLWithPath: Bundle.main.bundlePath).appendingPathComponent(fileName)
        let player:AVAudioPlayer!
        do {
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint:nil)
            player.delegate = self
            sePool.append(player)
            player.play()
        } catch  {
            print("AVAudioPlayerの作成に失敗しました")
        }
    }
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        if let index = sePool.index(of: player) {
            sePool.remove(at: index)
        }
    }
}
